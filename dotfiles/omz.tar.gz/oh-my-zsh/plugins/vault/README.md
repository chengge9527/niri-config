# Vault plugin

This plugin adds completion for [Vault](https://www.vaultproject.io/), the secrets and sensitive data manager.

To use it, add `vault` to the plugins array in your zshrc file:

```zsh
plugins=(... vault)
```
